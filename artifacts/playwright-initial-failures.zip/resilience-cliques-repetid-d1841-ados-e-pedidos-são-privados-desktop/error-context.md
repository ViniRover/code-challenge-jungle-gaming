# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: resilience.spec.ts >> cliques repetidos não criam pedidos duplicados e pedidos são privados
- Location: tests\e2e\resilience.spec.ts:45:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 2
```

# Page snapshot

```yaml
- generic [ref=f4e2]:
  - link "Pular para o conteúdo" [ref=f4e3] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f4e4]:
    - main [ref=f4e5]:
      - generic [ref=f4e6]:
        - heading "Seus NFTs agora estão na sua carteira" [level=1] [ref=f4e12]
        - generic [ref=f4e13]:
          - generic [ref=f4e14]:
            - text: ID da transação
            - generic [ref=f4e15]: 0x5746…0836
          - generic [ref=f4e16]:
            - text: Data
            - generic [ref=f4e17]: 27/10/2026
          - generic [ref=f4e18]:
            - text: Total
            - generic [ref=f4e19]: 1.206 ETH
          - generic [ref=f4e20]:
            - text: Carteira
            - generic [ref=f4e21]: MetaMask
        - generic [ref=f4e22]:
          - heading "Detalhes da transação" [level=2] [ref=f4e23]
          - generic [ref=f4e24]:
            - generic [ref=f4e25]: NFTs
            - generic [ref=f4e26]: Edições
            - generic [ref=f4e27]: Subtotal
          - generic [ref=f4e29]:
            - generic [ref=f4e30]:
              - text: "Emerald Ape #042"
              - generic [ref=f4e31]: "ID do token: #042"
              - generic [ref=f4e32]: "Edição: 1/50"
            - generic [ref=f4e33]: (× 1)
            - strong [ref=f4e34]: 1.19 ETH
          - generic [ref=f4e35]:
            - generic [ref=f4e36]:
              - term [ref=f4e37]: Subtotal
              - definition [ref=f4e38]: 1.19 ETH
            - generic [ref=f4e39]:
              - term [ref=f4e40]: Desconto do lançamento
              - definition [ref=f4e41]: (−) 0.00
            - generic [ref=f4e42]:
              - term [ref=f4e43]: Taxa de rede
              - definition [ref=f4e44]: 0.016 ETH
            - generic [ref=f4e45]:
              - term [ref=f4e46]: Informação sobre a taxa
              - definition [ref=f4e47]: Taxa estimada
            - generic [ref=f4e48]:
              - term [ref=f4e49]: Total
              - definition [ref=f4e50]: 1.206 ETH
          - status [ref=f4e51]: Transação confirmada na simulação. A propriedade foi transferida para sua carteira conectada e registrada na rede simulada.
          - button "Ver no Etherscan" [ref=f4e52] [cursor=pointer]
          - link "Continuar explorando" [ref=f4e53] [cursor=pointer]:
            - /url: /
    - generic [ref=f4e54]:
      - status [ref=f4e55]: Conectado
      - link "Demonstração" [ref=f4e57] [cursor=pointer]:
        - /url: /demo
  - region "Notifications alt+T":
    - list:
      - listitem:
        - button "Close toast" [ref=f4e58] [cursor=pointer]
        - generic: Preço ou disponibilidade atualizados. Revise seu carrinho.
      - listitem:
        - button "Close toast" [ref=f4e62] [cursor=pointer]
        - generic: Carteira conectada na simulação.
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { reset, login, request, addItem, prepareCheckout } from "./helpers";
  3  | test.beforeEach(async ({ page }) => reset(page));
  4  | test("respostas fora de ordem não substituem a busca mais recente", async ({
  5  |   page,
  6  |   isMobile,
  7  | }) => {
  8  |   await request(page, "/__demo", "PUT", { scenario: "out-of-order" });
  9  |   const search = page.getByRole("textbox", {
  10 |     name: isMobile ? "Explorar coleções" : "Buscar NFTs",
  11 |     exact: true,
  12 |   });
  13 |   await search.fill("E");
  14 |   await search.fill("Ivory");
  15 |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(4);
  16 |   await expect(page.locator(".nft-grid .nft-name").first()).toContainText(
  17 |     "Ivory",
  18 |   );
  19 |   await page.reload();
  20 |   await expect(page.locator(".nft-grid .nft-name").first()).toContainText(
  21 |     "Ivory",
  22 |   );
  23 | });
  24 | test("falha de conexão recupera após nova tentativa", async ({ page }) => {
  25 |   await request(page, "/__demo", "PUT", { scenario: "offline" });
  26 |   await page.goto("/nft/042");
  27 |   await expect(page.getByRole("alert")).toContainText("Sem conexão");
  28 |   await request(page, "/__demo", "PUT", { scenario: "standard" });
  29 |   await page.getByRole("button", { name: "Tentar novamente" }).click();
  30 |   await expect(
  31 |     page.getByRole("heading", { name: "Emerald Ape #042" }),
  32 |   ).toBeVisible();
  33 | });
  34 | test("edição esgotada e limite de quantidade", async ({ page }) => {
  35 |   await page.goto("/nft/042");
  36 |   await page.getByRole("button", { name: "1/1", exact: true }).click();
  37 |   await expect(
  38 |     page.getByRole("button", { name: "Aumentar quantidade" }),
  39 |   ).toBeDisabled();
  40 |   await request(page, "/__demo/event", "POST", { type: "stock", nftId: "042" });
  41 |   await expect(
  42 |     page.getByRole("button", { name: "1/50", exact: true }),
  43 |   ).toBeDisabled();
  44 | });
  45 | test("cliques repetidos não criam pedidos duplicados e pedidos são privados", async ({
  46 |   page,
  47 | }) => {
  48 |   await login(page);
  49 |   await addItem(page);
  50 |   await prepareCheckout(page);
  51 |   let calls = 0;
  52 |   page.on("request", (r) => {
  53 |     if (r.method() === "POST" && r.url().endsWith("/api/orders")) calls++;
  54 |   });
  55 |   await page
  56 |     .getByRole("button", { name: "Confirmar compra", exact: true })
  57 |     .click({ clickCount: 2 });
  58 |   await expect(
  59 |     page.getByRole("heading", {
  60 |       name: "Seus NFTs agora estão na sua carteira",
  61 |     }),
  62 |   ).toBeVisible();
> 63 |   expect(calls).toBe(1);
     |                 ^ Error: expect(received).toBe(expected) // Object.is equality
  64 |   const orderPath = new URL(page.url()).pathname;
  65 |   await page.goto("/profile");
  66 |   await page.getByRole("button", { name: "Sair", exact: true }).click();
  67 |   await login(page, "luna@kurio.test");
  68 |   await page.goto(orderPath);
  69 |   await expect(page.getByRole("alert")).toContainText("Pedido não encontrado");
  70 | });
  71 | test("avatar é salvo e restaurado após refresh", async ({ page }) => {
  72 |   await login(page);
  73 |   await page.locator("#avatar").setInputFiles("public/assets/emerald.webp");
  74 |   await page.getByRole("button", { name: "Salvar perfil" }).click();
  75 |   await expect(
  76 |     page.getByText("Perfil atualizado.", { exact: true }),
  77 |   ).toBeVisible();
  78 |   await page.reload();
  79 |   await expect(page.getByAltText("Seu avatar")).toBeVisible();
  80 |   await page.getByRole("button", { name: "Remover", exact: true }).click();
  81 |   await page.getByRole("button", { name: "Salvar perfil" }).click();
  82 |   await expect(
  83 |     page.getByText("Perfil atualizado.", { exact: true }),
  84 |   ).toBeVisible();
  85 |   await page.reload();
  86 |   await expect(page.getByAltText("Seu avatar")).not.toBeVisible();
  87 | });
  88 | 
```