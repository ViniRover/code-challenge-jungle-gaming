# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scenarios.spec.ts >> cadastro, conflito e senha com validação
- Location: tests\e2e\scenarios.spec.ts:39:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "já está cadastrado"
Error: strict mode violation: getByRole('alert') resolved to 2 elements:
    1) <p role="alert" class="field-error" id="auth-email-error">Este e-mail já está cadastrado.</p> aka locator('#auth-email-error')
    2) <div role="alert" class="error-state">…</div> aka locator('div').filter({ hasText: /^Este e-mail já está cadastrado\.$/ })

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 10000ms
  - waiting for getByRole('alert')

```

# Page snapshot

```yaml
- generic [active]:
  - generic:
    - link [aria-hidden]:
      - /url: "#main"
      - text: Pular para o conteúdo
    - generic [aria-hidden]:
      - navigation:
        - link:
          - /url: /
        - link:
          - /url: /favorites
        - link:
          - /url: /#catalogo
        - link:
          - /url: /cart
        - link:
          - /url: /profile
      - main:
        - generic [aria-hidden]:
          - generic:
            - textbox:
              - /placeholder: Explorar coleções
            - button
          - generic:
            - generic:
              - text: Bem-vindo à Kurio
              - heading [level=1]:
                - generic: SEJA DONO DA CULTURA DIGITAL
              - paragraph: Descubra NFTs selecionados de criadores emergentes e consagrados. Colecione arte digital rara, apoie artistas e tenha uma parte da cultura da internet.
              - link:
                - /url: "#catalogo"
                - text: EXPLORAR
          - generic:
            - generic:
              - generic:
                - generic:
                  - button [pressed]: Todos os NFTs
                  - button: Novos lançamentos
                  - button: Em alta
              - generic:
                - article:
                  - generic:
                    - link:
                      - /url: /nft/042
                    - button
                  - link:
                    - /url: /nft/042
                    - text: "Emerald Ape #042"
                  - generic:
                    - strong: 1.19 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/009
                    - button
                  - link:
                    - /url: /nft/009
                    - text: "Sage Nomad #009"
                  - generic:
                    - strong: 1.69 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/552
                    - generic: RARO
                    - button
                  - link:
                    - /url: /nft/552
                    - text: "Neon Vessel #552"
                  - generic:
                    - strong: 1.99 ETH
                    - deletion: 2.29 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/118
                    - button
                  - link:
                    - /url: /nft/118
                    - text: "Cosmic Bloom #118"
                  - generic:
                    - strong: 1.29 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/314
                    - button
                  - link:
                    - /url: /nft/314
                    - text: "Violet Nomad #314"
                  - generic:
                    - strong: 1.39 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/088
                    - button
                  - link:
                    - /url: /nft/088
                    - text: "Ivory Baron #088"
                  - generic:
                    - strong: 1.79 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/207
                    - button
                  - link:
                    - /url: /nft/207
                    - text: "Golden Beat #207"
                  - generic:
                    - strong: 0.99 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/071
                    - button
                  - link:
                    - /url: /nft/071
                    - text: "Golden Frequency #071"
                  - generic:
                    - strong: 0.59 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/160
                    - button
                  - link:
                    - /url: /nft/160
                    - text: "Golden Signal #160"
                  - generic:
                    - strong: 0.39 ETH
              - navigation:
                - button: "1"
                - button: "2"
                - button: "3"
                - button: "4"
                - button: ›
      - generic:
        - status: Conectado
        - link:
          - /url: /demo
          - text: Demonstração
    - region "Notifications alt+T"
  - dialog [ref=f2e2]:
    - generic [ref=f2e3]: KURIO
    - heading "Criar perfil de colecionador" [level=2] [ref=f2e4]
    - generic [ref=f2e6]:
      - generic [ref=f2e7]:
        - generic [ref=f2e8]: Nome de usuário
        - textbox "Nome de usuário" [ref=f2e9]: Novo Colecionador
      - generic [ref=f2e10]:
        - generic [ref=f2e11]: E-mail
        - textbox "E-mail" [invalid] [ref=f2e12]: nova@kurio.test
        - alert [ref=f2e13]: Este e-mail já está cadastrado.
      - generic [ref=f2e14]:
        - generic [ref=f2e15]: Senha
        - textbox "Senha" [ref=f2e16]: NovaSenha123!
        - button "Mostrar senha" [ref=f2e17] [cursor=pointer]
      - generic [ref=f2e23]:
        - generic [ref=f2e24]: Confirmar senha
        - textbox "Confirmar senha" [ref=f2e25]: NovaSenha123!
      - alert [ref=f2e26]:
        - paragraph [ref=f2e29]: Este e-mail já está cadastrado.
      - button "Criar conta" [ref=f2e30] [cursor=pointer]
    - generic [ref=f2e31]: Ou continue com
    - button "G Continuar com Google" [ref=f2e32] [cursor=pointer]:
      - generic [ref=f2e33]: G
      - text: Continuar com Google
    - button "f Continuar com Facebook" [ref=f2e34] [cursor=pointer]:
      - generic [ref=f2e35]: f
      - text: Continuar com Facebook
    - paragraph [ref=f2e36]:
      - text: Já tem uma conta?
      - link "Entre" [ref=f2e37] [cursor=pointer]:
        - /url: /login?redirect=%2Fprofile
    - generic [ref=f2e38]: "Demo: nova@kurio.test · Kurio123!"
    - button "Fechar" [ref=f2e39] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import { reset, login, addItem, prepareCheckout, request } from "./helpers";
  3   | test.beforeEach(async ({ page }) => reset(page));
  4   | test("busca, filtros combinados, ordenação, paginação e histórico", async ({
  5   |   page,
  6   |   isMobile,
  7   | }) => {
  8   |   await page.getByRole("button", { name: "Página 2", exact: true }).click();
  9   |   await expect(page).toHaveURL(/page=2/);
  10  |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(9);
  11  |   await page.reload();
  12  |   await expect(page).toHaveURL(/page=2/);
  13  |   if (isMobile)
  14  |     await page.getByRole("button", { name: "Abrir filtros" }).click();
  15  |   await page
  16  |     .getByRole("button", { name: "Arte digital (4)", exact: true })
  17  |     .click();
  18  |   await page
  19  |     .getByRole("button", { name: "Ethereum (12)", exact: true })
  20  |     .click();
  21  |   if (isMobile)
  22  |     await page.getByRole("button", { name: "Ver resultados" }).click();
  23  |   await expect(page).toHaveURL(/page=1/);
  24  |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(4);
  25  |   await page.goto("/?sort=price-asc");
  26  |   await expect(page.locator(".nft-grid .card-price strong").first()).toHaveText(
  27  |     "0.39 ETH",
  28  |   );
  29  |   await page
  30  |     .getByRole("textbox", {
  31  |       name: isMobile ? "Explorar coleções" : "Buscar NFTs",
  32  |       exact: true,
  33  |     })
  34  |     .fill("xyz-não-existe");
  35  |   await expect(page.getByText("Nenhum NFT encontrado")).toBeVisible();
  36  |   await page.goBack();
  37  |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(9);
  38  | });
  39  | test("cadastro, conflito e senha com validação", async ({ page }) => {
  40  |   await page.goto("/register");
  41  |   await page.getByRole("button", { name: "Criar conta", exact: true }).click();
  42  |   await expect(
  43  |     page.getByText("Informe pelo menos 2 caracteres."),
  44  |   ).toBeVisible();
  45  |   await page
  46  |     .getByLabel("Nome de usuário", { exact: true })
  47  |     .fill("Novo Colecionador");
  48  |   await page.getByLabel("E-mail", { exact: true }).fill("nova@kurio.test");
  49  |   await page.getByLabel("Senha", { exact: true }).fill("NovaSenha123!");
  50  |   await page
  51  |     .getByLabel("Confirmar senha", { exact: true })
  52  |     .fill("NovaSenha123!");
  53  |   await page.getByRole("button", { name: "Criar conta", exact: true }).click();
> 54  |   await expect(page.locator("#auth-email-error")).toContainText("já está cadastrado");
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  55  |   await page.getByLabel("E-mail", { exact: true }).fill("novo@kurio.test");
  56  |   await page.getByRole("button", { name: "Criar conta", exact: true }).click();
  57  |   await expect(page).toHaveURL(/\/profile$/);
  58  |   await page.reload();
  59  |   await expect(
  60  |     page.getByLabel("Nome de exibição", { exact: true }),
  61  |   ).toHaveValue("Novo Colecionador");
  62  | });
  63  | test("favorito otimista com rollback e isolamento entre usuários", async ({
  64  |   page,
  65  | }) => {
  66  |   await login(page);
  67  |   await page.goto("/nft/042");
  68  |   await request(page, "/__demo", "PUT", { scenario: "favorite-error" });
  69  |   const favorite = page
  70  |     .getByRole("button", { name: /^Favoritar/ })
  71  |     .filter({ visible: true })
  72  |     .first();
  73  |   await favorite.click();
  74  |   await expect(
  75  |     page.getByText("Não foi possível salvar o favorito.", { exact: true }),
  76  |   ).toBeVisible();
  77  |   await request(page, "/__demo", "PUT", { scenario: "standard" });
  78  |   await favorite.click();
  79  |   await expect(
  80  |     page.getByText("Favorito salvo.", { exact: true }),
  81  |   ).toBeVisible();
  82  |   await page.goto("/favorites");
  83  |   await expect(page.locator(".nft-card")).toHaveCount(1);
  84  |   await page.getByRole("button", { name: "Sair", exact: true }).click();
  85  |   await login(page, "luna@kurio.test");
  86  |   await page.goto("/favorites");
  87  |   await expect(page.getByText("Sua lista está vazia")).toBeVisible();
  88  | });
  89  | test("carrinho mescla visitante ao login, cupom e remoção", async ({
  90  |   page,
  91  | }) => {
  92  |   await addItem(page);
  93  |   await page.getByRole("button", { name: "Aumentar quantidade" }).click();
  94  |   await expect(page.locator(".total dd")).toHaveText("2.396 ETH");
  95  |   await page.getByLabel("Código promocional", { exact: true }).fill("INVALIDO");
  96  |   await page.getByRole("button", { name: "Aplicar", exact: true }).click();
  97  |   await expect(page.getByRole("alert")).toContainText("inválido");
  98  |   await page.getByLabel("Código promocional", { exact: true }).fill("KURIO10");
  99  |   await page.getByRole("button", { name: "Aplicar", exact: true }).click();
  100 |   await expect(page.locator(".total dd")).toHaveText("2.158 ETH");
  101 |   await login(page, "nova@kurio.test", "Kurio123!", "/cart");
  102 |   await expect(page.locator(".total dd")).toHaveText("2.158 ETH");
  103 |   await page.reload();
  104 |   await expect(page.locator(".cart-row")).toHaveCount(1);
  105 |   await page.getByRole("button", { name: "Remover cupom" }).click();
  106 |   await expect(page.locator(".total dd")).toHaveText("2.396 ETH");
  107 |   await page.getByRole("button", { name: "Remover Emerald Ape #042" }).click();
  108 |   await expect(page.getByText("Seu carrinho está vazio")).toBeVisible();
  109 | });
  110 | test("sessão expira no checkout e retoma contexto", async ({ page }) => {
  111 |   await login(page);
  112 |   await addItem(page);
  113 |   await page.goto("/checkout");
  114 |   await request(page, "/__demo", "PUT", { scenario: "expired-session" });
  115 |   await page.reload();
  116 |   await expect(page).toHaveURL(/\/login/);
  117 |   await page.getByLabel("E-mail", { exact: true }).fill("nova@kurio.test");
  118 |   await page.getByLabel("Senha", { exact: true }).fill("Kurio123!");
  119 |   await page.getByRole("button", { name: "Entrar", exact: true }).click();
  120 |   await expect(page).toHaveURL(/\/checkout$/);
  121 |   await expect(page.getByRole("radio").first()).toBeVisible();
  122 | });
  123 | test("pagamento recusado preserva carrinho", async ({ page }) => {
  124 |   await login(page);
  125 |   await addItem(page);
  126 |   await request(page, "/__demo", "PUT", {
  127 |     scenario: "payment-declined",
  128 |     paymentDelay: 400,
  129 |   });
  130 |   await prepareCheckout(page);
  131 |   await page
  132 |     .getByRole("button", { name: "Confirmar compra", exact: true })
  133 |     .click();
  134 |   await expect(
  135 |     page.getByRole("heading", { name: "Pagamento recusado" }),
  136 |   ).toBeVisible();
  137 |   await page.getByRole("link", { name: "Voltar ao carrinho" }).click();
  138 |   await expect(page.locator(".cart-row")).toHaveCount(1);
  139 | });
  140 | test("timeout após criação recupera o mesmo pedido", async ({ page }) => {
  141 |   await login(page);
  142 |   await addItem(page);
  143 |   await request(page, "/__demo", "PUT", {
  144 |     scenario: "order-timeout",
  145 |     paymentDelay: 1000,
  146 |   });
  147 |   await prepareCheckout(page);
  148 |   await page
  149 |     .getByRole("button", { name: "Confirmar compra", exact: true })
  150 |     .click();
  151 |   await expect(
  152 |     page.getByRole("heading", {
  153 |       name: "Seus NFTs agora estão na sua carteira",
  154 |     }),
```