# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scenarios.spec.ts >> perfil, avatar, senha e carteira persistem
- Location: tests\e2e\scenarios.spec.ts:226:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "senha atual está incorreta"
Error: strict mode violation: getByRole('alert') resolved to 2 elements:
    1) <span role="alert" class="field-error" id="currentPassword-error">Senha atual incorreta.</span> aka getByText('Senha atual incorreta.')
    2) <div role="alert" class="error-state">…</div> aka getByRole('alert').filter({ hasText: 'A senha atual está incorreta.' })

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 10000ms
  - waiting for getByRole('alert')

```

# Page snapshot

```yaml
- generic [ref=f2e2]:
  - link "Pular para o conteúdo" [ref=f2e3] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f2e4]:
    - navigation "Navegação mobile" [ref=f2e5]:
      - link "Início" [ref=f2e6] [cursor=pointer]:
        - /url: /
      - link "Favoritos" [ref=f2e10] [cursor=pointer]:
        - /url: /favorites
      - link "Explorar NFTs" [ref=f2e13] [cursor=pointer]:
        - /url: /#catalogo
      - link "Carrinho" [ref=f2e17] [cursor=pointer]:
        - /url: /cart
      - link "Meu perfil" [ref=f2e22] [cursor=pointer]:
        - /url: /profile
    - main [ref=f2e26]:
      - generic [ref=f2e27]:
        - complementary [ref=f2e28]:
          - link "Dados do perfil" [ref=f2e29] [cursor=pointer]:
            - /url: /profile
          - link "Carteiras" [ref=f2e33] [cursor=pointer]:
            - /url: /wallets
          - link "Lista de interesse" [ref=f2e37] [cursor=pointer]:
            - /url: /favorites
          - button "Sair" [ref=f2e40] [cursor=pointer]
        - generic [ref=f2e44]:
          - heading "Perfil do colecionador" [level=1] [ref=f2e45]
          - generic [ref=f2e46]:
            - generic [ref=f2e47]:
              - generic [ref=f2e48]:
                - generic [ref=f2e49]: Nome de exibição*
                - textbox "Nome de exibição" [ref=f2e50]: Nova Atualizada
              - generic [ref=f2e51]:
                - generic [ref=f2e52]: Nome de usuário*
                - textbox "Nome de usuário" [ref=f2e53]: nova
              - generic [ref=f2e54]:
                - generic [ref=f2e55]: E-mail*
                - textbox "E-mail" [ref=f2e56]: nova@kurio.test
              - generic [ref=f2e57]:
                - generic [ref=f2e58]: Nome ENS
                - textbox "Nome ENS" [ref=f2e59]: nova.kurio.eth
              - generic [ref=f2e60]:
                - generic [ref=f2e61]: Apelido da carteira
                - textbox "Apelido da carteira" [ref=f2e62]: Principal
              - generic [ref=f2e63]:
                - generic [ref=f2e64]: Avatar
                - generic [ref=f2e65]:
                  - generic [ref=f2e71] [cursor=pointer]: Alterar
                  - button "Avatar Alterar" [ref=f2e72]
                  - button "Remover" [ref=f2e73] [cursor=pointer]
            - button "Salvar perfil" [ref=f2e74] [cursor=pointer]
          - generic [ref=f2e75]:
            - heading "Alterar senha" [level=2] [ref=f2e76]
            - generic [ref=f2e77]:
              - generic [ref=f2e78]: Senha atual
              - textbox "Senha atual" [invalid] [ref=f2e79]: errada
              - alert [ref=f2e80]: Senha atual incorreta.
            - generic [ref=f2e81]:
              - generic [ref=f2e82]: Nova senha
              - textbox "Nova senha" [ref=f2e83]: Kurio456!
            - generic [ref=f2e84]:
              - generic [ref=f2e85]: Confirmar nova senha
              - textbox "Confirmar nova senha" [ref=f2e86]: Kurio456!
            - alert [ref=f2e87]:
              - paragraph [ref=f2e90]: A senha atual está incorreta.
            - button "Alterar senha" [ref=f2e91] [cursor=pointer]
    - generic [ref=f2e92]:
      - status [ref=f2e93]: Conectado
      - link "Demonstração" [ref=f2e95] [cursor=pointer]:
        - /url: /demo
  - region "Notifications alt+T":
    - list:
      - listitem:
        - button "Close toast" [ref=f2e96] [cursor=pointer]
        - generic: Perfil atualizado.
      - listitem:
        - button "Close toast" [ref=f2e100] [cursor=pointer]
        - generic: Bem-vindo de volta.
```

# Test source

```ts
  143 |   await request(page, "/__demo", "PUT", {
  144 |     scenario: "order-timeout",
  145 |     paymentDelay: 1000,
  146 |   });
  147 |   await prepareCheckout(page);
  148 |   await page
  149 |     .getByRole("button", { name: "Confirmar compra", exact: true })
  150 |     .click();
  151 |   await expect(
  152 |     page.getByRole("heading", {
  153 |       name: "Seus NFTs agora estão na sua carteira",
  154 |     }),
  155 |   ).toBeVisible({ timeout: 20000 });
  156 |   const url = page.url();
  157 |   await page.reload();
  158 |   await expect(page).toHaveURL(url);
  159 |   await expect(
  160 |     page.getByRole("heading", {
  161 |       name: "Seus NFTs agora estão na sua carteira",
  162 |     }),
  163 |   ).toBeVisible();
  164 | });
  165 | test("Socket.IO atualiza preço, ignora duplicatas e impede cotação antiga", async ({
  166 |   page,
  167 | }) => {
  168 |   await login(page);
  169 |   await addItem(page);
  170 |   await prepareCheckout(page);
  171 |   await expect(page.locator(".connection-status")).toContainText("Conectado");
  172 |   await request(page, "/__demo/event", "POST", {
  173 |     type: "price",
  174 |     nftId: "042",
  175 |     price: "1.49",
  176 |   });
  177 |   await expect(
  178 |     page.getByText(
  179 |       "A cotação mudou. Feche esta revisão e confira os novos valores.",
  180 |     ),
  181 |   ).toBeVisible();
  182 |   await expect(
  183 |     page.getByRole("button", { name: "Confirmar compra", exact: true }),
  184 |   ).toBeDisabled();
  185 |   await page.getByRole("button", { name: "Fechar", exact: true }).click();
  186 |   await expect(page.locator(".checkout-summary .total dd")).toHaveText(
  187 |     "1.506 ETH",
  188 |   );
  189 |   await request(page, "/__demo/event", "POST", {
  190 |     type: "duplicate",
  191 |     nftId: "042",
  192 |   });
  193 |   await expect(page.locator(".checkout-summary .total dd")).toHaveText(
  194 |     "1.506 ETH",
  195 |   );
  196 |   await request(page, "/__demo/event", "POST", { type: "stock", nftId: "042" });
  197 |   await expect(
  198 |     page.getByRole("alert").filter({ hasText: "edição indisponível" }),
  199 |   ).toBeVisible();
  200 | });
  201 | test("pedido pendente recupera após desconexão e refresh", async ({ page }) => {
  202 |   await login(page);
  203 |   await addItem(page);
  204 |   await request(page, "/__demo", "PUT", { scenario: "pending-order" });
  205 |   await prepareCheckout(page);
  206 |   await page
  207 |     .getByRole("button", { name: "Confirmar compra", exact: true })
  208 |     .click();
  209 |   await expect(
  210 |     page.getByRole("heading", { name: "Seu pedido está sendo processado" }),
  211 |   ).toBeVisible();
  212 |   const url = page.url();
  213 |   await request(page, "/__demo/event", "POST", { type: "disconnect" });
  214 |   await page.reload();
  215 |   await expect(page).toHaveURL(url);
  216 |   await expect(
  217 |     page.getByRole("heading", { name: "Seu pedido está sendo processado" }),
  218 |   ).toBeVisible();
  219 |   await request(page, "/__demo/event", "POST", { type: "resolve-order" });
  220 |   await expect(
  221 |     page.getByRole("heading", {
  222 |       name: "Seus NFTs agora estão na sua carteira",
  223 |     }),
  224 |   ).toBeVisible();
  225 | });
  226 | test("perfil, avatar, senha e carteira persistem", async ({ page }) => {
  227 |   await login(page);
  228 |   await page
  229 |     .getByLabel("Nome de exibição", { exact: true })
  230 |     .fill("Nova Atualizada");
  231 |   await page.getByRole("button", { name: "Salvar perfil" }).click();
  232 |   await expect(
  233 |     page.getByText("Perfil atualizado.", { exact: true }),
  234 |   ).toBeVisible();
  235 |   await page.getByLabel("Senha atual", { exact: true }).fill("errada");
  236 |   await page.getByLabel("Nova senha", { exact: true }).fill("Kurio456!");
  237 |   await page
  238 |     .getByLabel("Confirmar nova senha", { exact: true })
  239 |     .fill("Kurio456!");
  240 |   await page
  241 |     .getByRole("button", { name: "Alterar senha", exact: true })
  242 |     .click();
> 243 |   await expect(page.locator(".error-state")).toContainText(
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  244 |     "senha atual está incorreta",
  245 |   );
  246 |   await page.getByLabel("Senha atual", { exact: true }).fill("Kurio123!");
  247 |   await page
  248 |     .getByRole("button", { name: "Alterar senha", exact: true })
  249 |     .click();
  250 |   await expect(
  251 |     page.getByText("Senha alterada.", { exact: true }),
  252 |   ).toBeVisible();
  253 |   await page.goto("/wallets");
  254 |   await page
  255 |     .getByLabel("Endereço da carteira", { exact: true })
  256 |     .fill("invalid");
  257 |   await page.getByRole("button", { name: "Salvar carteira" }).click();
  258 |   await expect(
  259 |     page.getByText("Endereço incompatível com a rede selecionada."),
  260 |   ).toBeVisible();
  261 |   await page
  262 |     .getByLabel("Endereço da carteira", { exact: true })
  263 |     .fill("0x1111111111111111111111111111111111111111");
  264 |   await page.getByRole("button", { name: "Salvar carteira" }).click();
  265 |   await expect(
  266 |     page.getByText("Carteira salva.", { exact: true }),
  267 |   ).toBeVisible();
  268 |   await page.reload();
  269 |   await expect(
  270 |     page.getByLabel("Endereço da carteira", { exact: true }),
  271 |   ).toHaveValue("0x1111111111111111111111111111111111111111");
  272 | });
  273 | test("skeleton, erro transitório e recuperação", async ({ page }) => {
  274 |   await request(page, "/__demo", "PUT", { scenario: "slow" });
  275 |   await page.goto("/nft/042");
  276 |   await expect(
  277 |     page.getByRole("status", { name: "Carregando detalhe" }),
  278 |   ).toBeVisible();
  279 |   await expect(
  280 |     page.getByRole("heading", { name: "Emerald Ape #042" }),
  281 |   ).toBeVisible();
  282 |   await request(page, "/__demo", "PUT", { scenario: "server-error" });
  283 |   await page.goto("/");
  284 |   await expect(
  285 |     page
  286 |       .getByRole("alert")
  287 |       .filter({ hasText: "Serviço temporariamente indisponível" }),
  288 |   ).toBeVisible();
  289 |   await request(page, "/__demo", "PUT", { scenario: "standard" });
  290 |   await page.getByRole("button", { name: "Tentar novamente" }).click();
  291 |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(9);
  292 | });
  293 | test("teclado, foco preso no diálogo e ausência de overflow", async ({
  294 |   page,
  295 | }) => {
  296 |   await page.goto("/login");
  297 |   await expect(page.getByRole("dialog")).toBeVisible();
  298 |   for (let i = 0; i < 14; i++) {
  299 |     await page.keyboard.press("Tab");
  300 |     await expect
  301 |       .poll(() =>
  302 |         page.evaluate(
  303 |           () => !!document.activeElement?.closest('[role="dialog"]'),
  304 |         ),
  305 |       )
  306 |       .toBe(true);
  307 |   }
  308 |   await page.keyboard.press("Escape");
  309 |   await expect(page.getByRole("dialog")).not.toBeVisible();
  310 |   for (const width of [390, 768, 1440]) {
  311 |     await page.setViewportSize({ width, height: 1000 });
  312 |     await expect
  313 |       .poll(() =>
  314 |         page.evaluate(
  315 |           () => document.documentElement.scrollWidth <= window.innerWidth,
  316 |         ),
  317 |       )
  318 |       .toBe(true);
  319 |   }
  320 | });
  321 | 
```