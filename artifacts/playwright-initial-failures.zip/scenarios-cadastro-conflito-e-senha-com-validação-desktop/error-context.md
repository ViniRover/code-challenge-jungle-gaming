# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scenarios.spec.ts >> cadastro, conflito e senha com validação
- Location: tests\e2e\scenarios.spec.ts:39:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "já está cadastrado"
Error: strict mode violation: getByRole('alert') resolved to 2 elements:
    1) <p role="alert" class="field-error" id="auth-email-error">Este e-mail já está cadastrado.</p> aka locator('#auth-email-error')
    2) <div role="alert" class="error-state">…</div> aka locator('div').filter({ hasText: /^Este e-mail já está cadastrado\.$/ })

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 10000ms
  - waiting for getByRole('alert')

```

# Page snapshot

```yaml
- generic [active]:
  - generic:
    - link [aria-hidden]:
      - /url: "#main"
      - text: Pular para o conteúdo
    - generic [aria-hidden]:
      - banner:
        - link:
          - /url: /
          - text: KURIO
        - navigation:
          - link:
            - /url: /
            - text: Início
          - link:
            - /url: /#catalogo
            - text: Mercado
          - button: Criadores
          - button: Aprenda
        - generic:
          - button
          - link:
            - /url: /cart
            - generic: "0"
          - link:
            - /url: /login?redirect=%2Fregister
            - text: Entrar
      - main:
        - generic [aria-hidden]:
          - generic:
            - generic:
              - text: Bem-vindo à Kurio
              - heading [level=1]:
                - generic: SEJA DONO DO FUTURO DA ARTE DIGITAL
              - paragraph: Descubra NFTs selecionados de criadores emergentes e consagrados. Colecione arte digital rara, apoie artistas e tenha uma parte da cultura da internet.
              - link:
                - /url: "#catalogo"
                - text: EXPLORAR
          - generic:
            - complementary:
              - generic:
                - heading [level=2]: Coleções
                - button:
                  - generic: Arte digital
                  - generic: (4)
                - button:
                  - generic: Fotografia
                  - generic: (4)
                - button:
                  - generic: Música
                  - generic: (4)
                - button:
                  - generic: Arte 3D
                  - generic: (4)
                - button:
                  - generic: Colecionáveis
                  - generic: (4)
                - button:
                  - generic: Generativa
                  - generic: (4)
                - button:
                  - generic: Jogos
                  - generic: (4)
                - button:
                  - generic: Assinaturas
                  - generic: (4)
                - button:
                  - generic: Utilidade
                  - generic: (4)
                - heading [level=2]: Faixa de preço
                - generic:
                  - generic: Preço mínimo
                  - slider: "0.02"
                  - generic:
                    - generic:
                      - text: Mín.
                      - spinbutton: "0.02"
                    - generic:
                      - text: Máx.
                      - spinbutton: "12.30"
                  - button: Aplicar
                - heading [level=2]: Rede
                - button:
                  - generic: Ethereum
                  - generic: (12)
                - button:
                  - generic: Polygon
                  - generic: (12)
                - button:
                  - generic: Solana
                  - generic: (12)
                - button: Limpar filtros
              - generic:
                - heading [level=3]: NFT EM DESTAQUE
                - text: OFERTA LIMITADA
            - generic:
              - generic:
                - generic:
                  - button [pressed]: Todos os NFTs
                  - button: Novos lançamentos
                  - button: Em alta
                - generic:
                  - text: "Ordenar por:"
                  - combobox
              - generic:
                - textbox:
                  - /placeholder: Buscar NFTs…
              - generic:
                - article:
                  - generic:
                    - link:
                      - /url: /nft/042
                    - button
                    - generic:
                      - link:
                        - /url: /nft/042
                      - link:
                        - /url: /nft/042
                  - link:
                    - /url: /nft/042
                    - text: "Emerald Ape #042"
                  - generic:
                    - strong: 1.19 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/009
                    - button
                    - generic:
                      - link:
                        - /url: /nft/009
                      - link:
                        - /url: /nft/009
                  - link:
                    - /url: /nft/009
                    - text: "Sage Nomad #009"
                  - generic:
                    - strong: 1.69 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/552
                    - generic: RARO
                    - button
                    - generic:
                      - link:
                        - /url: /nft/552
                      - link:
                        - /url: /nft/552
                  - link:
                    - /url: /nft/552
                    - text: "Neon Vessel #552"
                  - generic:
                    - strong: 1.99 ETH
                    - deletion: 2.29 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/118
                    - button
                    - generic:
                      - link:
                        - /url: /nft/118
                      - link:
                        - /url: /nft/118
                  - link:
                    - /url: /nft/118
                    - text: "Cosmic Bloom #118"
                  - generic:
                    - strong: 1.29 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/314
                    - button
                    - generic:
                      - link:
                        - /url: /nft/314
                      - link:
                        - /url: /nft/314
                  - link:
                    - /url: /nft/314
                    - text: "Violet Nomad #314"
                  - generic:
                    - strong: 1.39 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/088
                    - button
                    - generic:
                      - link:
                        - /url: /nft/088
                      - link:
                        - /url: /nft/088
                  - link:
                    - /url: /nft/088
                    - text: "Ivory Baron #088"
                  - generic:
                    - strong: 1.79 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/207
                    - button
                    - generic:
                      - link:
                        - /url: /nft/207
                      - link:
                        - /url: /nft/207
                  - link:
                    - /url: /nft/207
                    - text: "Golden Beat #207"
                  - generic:
                    - strong: 0.99 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/071
                    - button
                    - generic:
                      - link:
                        - /url: /nft/071
                      - link:
                        - /url: /nft/071
                  - link:
                    - /url: /nft/071
                    - text: "Golden Frequency #071"
                  - generic:
                    - strong: 0.59 ETH
                - article:
                  - generic:
                    - link:
                      - /url: /nft/160
                    - button
                    - generic:
                      - link:
                        - /url: /nft/160
                      - link:
                        - /url: /nft/160
                  - link:
                    - /url: /nft/160
                    - text: "Golden Signal #160"
                  - generic:
                    - strong: 0.39 ETH
              - navigation:
                - button: "1"
                - button: "2"
                - button: "3"
                - button: "4"
                - button: ›
          - generic:
            - generic:
              - generic:
                - heading [level=3]: Lançamentos gênesis de edição limitada
                - paragraph: Colecione edições escassas diretamente dos criadores e descubra obras digitais.
                - link:
                  - /url: /#catalogo
                  - text: Explorar →
            - generic:
              - generic:
                - heading [level=3]: Arte digital selecionada e muito mais
                - paragraph: Colecione edições escassas diretamente dos criadores e descubra obras digitais.
                - link:
                  - /url: /#catalogo
                  - text: Explorar →
          - generic:
            - heading [level=2]: Diário da Cunhagem
            - paragraph: Histórias, guias e insights para colecionadores sobre o universo da propriedade digital.
            - generic:
              - article:
                - generic:
                  - text: 12 de setembro | Leitura de 3 min
                  - heading [level=3]: Como funciona a propriedade de NFTs
                  - paragraph: Conheça o universo da arte digital.
                  - button: Ler mais →
              - article:
                - generic:
                  - text: 12 de setembro | Leitura de 3 min
                  - heading [level=3]: 10 artistas digitais para acompanhar
                  - paragraph: Conheça o universo da arte digital.
                  - button: Ler mais →
              - article:
                - generic:
                  - text: 12 de setembro | Leitura de 3 min
                  - heading [level=3]: Raridade, atributos e procedência
                  - paragraph: Conheça o universo da arte digital.
                  - button: Ler mais →
              - article:
                - generic:
                  - text: 12 de setembro | Leitura de 3 min
                  - heading [level=3]: Como proteger sua carteira
                  - paragraph: Conheça o universo da arte digital.
                  - button: Ler mais →
      - contentinfo:
        - generic:
          - generic:
            - generic: W
            - heading [level=3]: Segurança da carteira
            - paragraph: Proteja sua carteira e colecione arte digital verificada com confiança.
          - generic:
            - generic: C
            - heading [level=3]: Criadores em destaque
            - paragraph: Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede.
          - generic:
            - generic: D
            - heading [level=3]: Alertas de lançamentos
            - paragraph: Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado.
          - generic:
            - heading [level=3]: Antecipe-se ao próximo lançamento
            - generic:
              - textbox:
                - /placeholder: digite seu e-mail...
              - button: Enviar
            - paragraph: Receba lançamentos selecionados, histórias de criadores e novidades do mercado.
        - generic:
          - link:
            - /url: /
            - text: KURIO
          - paragraph: Feito para colecionadores, criadores e cultura
          - generic: contato@email.com
          - generic: +55 11 4002 8922
        - generic:
          - generic:
            - heading [level=3]: Meu perfil
            - link:
              - /url: /profile
              - text: Meu perfil
            - link:
              - /url: /favorites
              - text: Minha coleção
            - button: Atividade
            - button: Estúdio do criador
            - link:
              - /url: /favorites
              - text: Lista de interesse
          - generic:
            - heading [level=3]: Central de ajuda
            - button: Central de ajuda
            - button: Como comprar NFTs
            - button: Carteira e segurança
            - button: Política do mercado
            - button: Denunciar item
          - generic:
            - heading [level=3]: Coleções
            - link:
              - /url: /?category=Arte+digital&page=1
              - text: Arte digital
            - link:
              - /url: /?category=Fotografia&page=1
              - text: Fotografia
            - link:
              - /url: /?category=M%C3%BAsica&page=1
              - text: Música
            - link:
              - /url: /?category=Arte+3D&page=1
              - text: Arte 3D
            - link:
              - /url: /?category=Utilidade&page=1
              - text: Utilidade
          - generic:
            - heading [level=3]: Redes sociais
            - generic:
              - button: f
              - button: ◎
              - button: 𝕏
              - button: in
              - button: ▶
            - heading [level=3]: Carteiras compatíveis
            - text: METAMASK · WALLETCONNECT · COINBASE
        - paragraph: © 2026 Kurio. Propriedade digital para todos.
      - generic:
        - status: Conectado
        - link:
          - /url: /demo
          - text: Demonstração
    - region "Notifications alt+T"
  - dialog [ref=f2e2]:
    - heading [level=2] [ref=f2e3]:
      - generic [ref=f2e4]:
        - link "Entrar" [ref=f2e5] [cursor=pointer]:
          - /url: /login?redirect=%2Fprofile
        - text: "|"
        - link "Criar conta" [ref=f2e6] [cursor=pointer]:
          - /url: /register?redirect=%2Fprofile
    - paragraph [ref=f2e7]: Crie seu perfil de colecionador e conecte uma carteira quando quiser.
    - generic [ref=f2e8]:
      - generic [ref=f2e9]:
        - generic [ref=f2e10]: Nome de usuário
        - textbox "Nome de usuário" [ref=f2e11]: Novo Colecionador
      - generic [ref=f2e12]:
        - generic [ref=f2e13]: E-mail
        - textbox "E-mail" [invalid] [ref=f2e14]: nova@kurio.test
        - alert [ref=f2e15]: Este e-mail já está cadastrado.
      - generic [ref=f2e16]:
        - generic [ref=f2e17]: Senha
        - textbox "Senha" [ref=f2e18]: NovaSenha123!
        - button "Mostrar senha" [ref=f2e19] [cursor=pointer]
      - generic [ref=f2e25]:
        - generic [ref=f2e26]: Confirmar senha
        - textbox "Confirmar senha" [ref=f2e27]: NovaSenha123!
      - alert [ref=f2e28]:
        - paragraph [ref=f2e31]: Este e-mail já está cadastrado.
      - button "Criar conta" [ref=f2e32] [cursor=pointer]
    - generic [ref=f2e33]: Ou continue com
    - button "G Continuar com Google" [ref=f2e34] [cursor=pointer]:
      - generic [ref=f2e35]: G
      - text: Continuar com Google
    - button "f Continuar com Facebook" [ref=f2e36] [cursor=pointer]:
      - generic [ref=f2e37]: f
      - text: Continuar com Facebook
    - generic [ref=f2e38]: "Demo: nova@kurio.test · Kurio123!"
    - button "Fechar" [ref=f2e39] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import { reset, login, addItem, prepareCheckout, request } from "./helpers";
  3   | test.beforeEach(async ({ page }) => reset(page));
  4   | test("busca, filtros combinados, ordenação, paginação e histórico", async ({
  5   |   page,
  6   |   isMobile,
  7   | }) => {
  8   |   await page.getByRole("button", { name: "Página 2", exact: true }).click();
  9   |   await expect(page).toHaveURL(/page=2/);
  10  |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(9);
  11  |   await page.reload();
  12  |   await expect(page).toHaveURL(/page=2/);
  13  |   if (isMobile)
  14  |     await page.getByRole("button", { name: "Abrir filtros" }).click();
  15  |   await page
  16  |     .getByRole("button", { name: "Arte digital (4)", exact: true })
  17  |     .click();
  18  |   await page
  19  |     .getByRole("button", { name: "Ethereum (12)", exact: true })
  20  |     .click();
  21  |   if (isMobile)
  22  |     await page.getByRole("button", { name: "Ver resultados" }).click();
  23  |   await expect(page).toHaveURL(/page=1/);
  24  |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(4);
  25  |   await page.goto("/?sort=price-asc");
  26  |   await expect(page.locator(".nft-grid .card-price strong").first()).toHaveText(
  27  |     "0.39 ETH",
  28  |   );
  29  |   await page
  30  |     .getByRole("textbox", {
  31  |       name: isMobile ? "Explorar coleções" : "Buscar NFTs",
  32  |       exact: true,
  33  |     })
  34  |     .fill("xyz-não-existe");
  35  |   await expect(page.getByText("Nenhum NFT encontrado")).toBeVisible();
  36  |   await page.goBack();
  37  |   await expect(page.locator(".nft-grid .nft-card")).toHaveCount(9);
  38  | });
  39  | test("cadastro, conflito e senha com validação", async ({ page }) => {
  40  |   await page.goto("/register");
  41  |   await page.getByRole("button", { name: "Criar conta", exact: true }).click();
  42  |   await expect(
  43  |     page.getByText("Informe pelo menos 2 caracteres."),
  44  |   ).toBeVisible();
  45  |   await page
  46  |     .getByLabel("Nome de usuário", { exact: true })
  47  |     .fill("Novo Colecionador");
  48  |   await page.getByLabel("E-mail", { exact: true }).fill("nova@kurio.test");
  49  |   await page.getByLabel("Senha", { exact: true }).fill("NovaSenha123!");
  50  |   await page
  51  |     .getByLabel("Confirmar senha", { exact: true })
  52  |     .fill("NovaSenha123!");
  53  |   await page.getByRole("button", { name: "Criar conta", exact: true }).click();
> 54  |   await expect(page.getByRole("alert")).toContainText("já está cadastrado");
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  55  |   await page.getByLabel("E-mail", { exact: true }).fill("novo@kurio.test");
  56  |   await page.getByRole("button", { name: "Criar conta", exact: true }).click();
  57  |   await expect(page).toHaveURL(/\/profile$/);
  58  |   await page.reload();
  59  |   await expect(
  60  |     page.getByLabel("Nome de exibição", { exact: true }),
  61  |   ).toHaveValue("Novo Colecionador");
  62  | });
  63  | test("favorito otimista com rollback e isolamento entre usuários", async ({
  64  |   page,
  65  | }) => {
  66  |   await login(page);
  67  |   await page.goto("/nft/042");
  68  |   await request(page, "/__demo", "PUT", { scenario: "favorite-error" });
  69  |   const favorite = page
  70  |     .getByRole("button", { name: /^Favoritar/ })
  71  |     .filter({ visible: true })
  72  |     .first();
  73  |   await favorite.click();
  74  |   await expect(
  75  |     page.getByText("Não foi possível salvar o favorito.", { exact: true }),
  76  |   ).toBeVisible();
  77  |   await request(page, "/__demo", "PUT", { scenario: "standard" });
  78  |   await favorite.click();
  79  |   await expect(
  80  |     page.getByText("Favorito salvo.", { exact: true }),
  81  |   ).toBeVisible();
  82  |   await page.goto("/favorites");
  83  |   await expect(page.locator(".nft-card")).toHaveCount(1);
  84  |   await page.getByRole("button", { name: "Sair", exact: true }).click();
  85  |   await login(page, "luna@kurio.test");
  86  |   await page.goto("/favorites");
  87  |   await expect(page.getByText("Sua lista está vazia")).toBeVisible();
  88  | });
  89  | test("carrinho mescla visitante ao login, cupom e remoção", async ({
  90  |   page,
  91  | }) => {
  92  |   await addItem(page);
  93  |   await page.getByRole("button", { name: "Aumentar quantidade" }).click();
  94  |   await expect(page.locator(".total dd")).toHaveText("2.396 ETH");
  95  |   await page.getByLabel("Código promocional", { exact: true }).fill("INVALIDO");
  96  |   await page.getByRole("button", { name: "Aplicar", exact: true }).click();
  97  |   await expect(page.getByRole("alert")).toContainText("inválido");
  98  |   await page.getByLabel("Código promocional", { exact: true }).fill("KURIO10");
  99  |   await page.getByRole("button", { name: "Aplicar", exact: true }).click();
  100 |   await expect(page.locator(".total dd")).toHaveText("2.158 ETH");
  101 |   await login(page, "nova@kurio.test", "Kurio123!", "/cart");
  102 |   await expect(page.locator(".total dd")).toHaveText("2.158 ETH");
  103 |   await page.reload();
  104 |   await expect(page.locator(".cart-row")).toHaveCount(1);
  105 |   await page.getByRole("button", { name: "Remover cupom" }).click();
  106 |   await expect(page.locator(".total dd")).toHaveText("2.396 ETH");
  107 |   await page.getByRole("button", { name: "Remover Emerald Ape #042" }).click();
  108 |   await expect(page.getByText("Seu carrinho está vazio")).toBeVisible();
  109 | });
  110 | test("sessão expira no checkout e retoma contexto", async ({ page }) => {
  111 |   await login(page);
  112 |   await addItem(page);
  113 |   await page.goto("/checkout");
  114 |   await request(page, "/__demo", "PUT", { scenario: "expired-session" });
  115 |   await page.reload();
  116 |   await expect(page).toHaveURL(/\/login/);
  117 |   await page.getByLabel("E-mail", { exact: true }).fill("nova@kurio.test");
  118 |   await page.getByLabel("Senha", { exact: true }).fill("Kurio123!");
  119 |   await page.getByRole("button", { name: "Entrar", exact: true }).click();
  120 |   await expect(page).toHaveURL(/\/checkout$/);
  121 |   await expect(page.getByRole("radio").first()).toBeVisible();
  122 | });
  123 | test("pagamento recusado preserva carrinho", async ({ page }) => {
  124 |   await login(page);
  125 |   await addItem(page);
  126 |   await request(page, "/__demo", "PUT", {
  127 |     scenario: "payment-declined",
  128 |     paymentDelay: 400,
  129 |   });
  130 |   await prepareCheckout(page);
  131 |   await page
  132 |     .getByRole("button", { name: "Confirmar compra", exact: true })
  133 |     .click();
  134 |   await expect(
  135 |     page.getByRole("heading", { name: "Pagamento recusado" }),
  136 |   ).toBeVisible();
  137 |   await page.getByRole("link", { name: "Voltar ao carrinho" }).click();
  138 |   await expect(page.locator(".cart-row")).toHaveCount(1);
  139 | });
  140 | test("timeout após criação recupera o mesmo pedido", async ({ page }) => {
  141 |   await login(page);
  142 |   await addItem(page);
  143 |   await request(page, "/__demo", "PUT", {
  144 |     scenario: "order-timeout",
  145 |     paymentDelay: 1000,
  146 |   });
  147 |   await prepareCheckout(page);
  148 |   await page
  149 |     .getByRole("button", { name: "Confirmar compra", exact: true })
  150 |     .click();
  151 |   await expect(
  152 |     page.getByRole("heading", {
  153 |       name: "Seus NFTs agora estão na sua carteira",
  154 |     }),
```